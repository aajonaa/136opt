# Cluster-Guided Particle Light Optimization with Differential Recombination
1. Comparison of Optimal Solutions of Clusters  Created Using Clustering Algorithm with MetaHeuristic Algorithms in Capacity Vehicle Routing  Problem
2. Backtracking Search Optimization Algorithm for numerical optimization

## CDPLO: Cluster Differential Particle Light Optimization
- PLO with Cluster-guidance and Differential Recombination