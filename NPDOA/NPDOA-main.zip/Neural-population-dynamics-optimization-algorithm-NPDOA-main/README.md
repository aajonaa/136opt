# Neural-population-dynamics-optimization-algorithm-NPDOA

The code of NPDOA. Just put the code into \PlatEMO-4.1\PlatEMO\Algorithms\Single-objective optimization\ 


Junzhong Ji, Tongxuan Wu, Cuicui Yang,
Neural population dynamics optimization algorithm: A novel brain-inspired meta-heuristic method,
Knowledge-Based Systems,
Volume 300,
2024,
112194,
ISSN 0950-7051,
https://doi.org/10.1016/j.knosys.2024.112194.
